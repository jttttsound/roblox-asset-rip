Credit goes to @zyme-xd (https://github.com/zyme-xd) for the original RBLX-RIP

I just made this much more simpler instead of having to do all the nodejs stuff and yada-yada

How to use
1: Extract the file
2: Run the .exe
3: Get a random shirt or something that you want to rip (keep in mind that some assets need to be onsale to be ripped)
4: Paste in the ID, press enter and then type the "type of asset" (you can find a list of supported assets on the github or on https://cdn.calones.xyz/651d67fd9d90d716.txt)
5: Press enter, and when it closes, it should be uploaded to the assets folder (/RBLX-RIP/assets)
6: It should work and you have a ripped roblox asset

happy ripping
riot33k